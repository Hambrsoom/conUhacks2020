﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetCurrentRTTCallDoesntCrashWhenUseWebSockets_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "GetCurrentRTTCallDoesntCrashWhenUseWebSockets_BridgeScriptGO";

    public GameObject playerPrefab;
}
